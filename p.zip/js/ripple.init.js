
//Ripples js
$(home).ripples({
    resolution: 512,
    dropRadius: 15,
    perturbance: 0.01,
});