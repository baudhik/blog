//Text Rotate
$(".simple-text-rotate").textrotator({
    animation: "fade",
    speed: 3500
});